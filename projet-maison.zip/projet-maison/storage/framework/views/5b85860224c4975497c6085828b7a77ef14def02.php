<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-xl font-semibold leading-tight text-gray-800">
            <?php echo e(__('Mes objets connectés')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-8">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow sm:rounded-lg p-6">

                <h3 class="text-lg font-bold mb-4">
                    Liste de mes objets connectés
                </h3>

                
                <p class="text-gray-600 mb-4">
                    Vous n'avez pas encore d’objet connecté. Cliquez sur le bouton ci-dessous pour en ajouter un.
                </p>

                
                <a href="#" class="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700">
                    Ajouter un objet connecté
                </a>

                
                
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\enora\OneDrive\Documents\ING 1\S2\maison_connectee\projet-maison\resources\views/objets/index.blade.php ENDPATH**/ ?>