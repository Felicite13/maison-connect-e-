<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="text-xl font-semibold leading-tight text-gray-800">
            <?php echo e(__('Mon Tableau de bord')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-8">
        <div class="mx-auto max-w-7xl sm:px-6 lg:px-8">
            <div class="overflow-hidden bg-white shadow sm:rounded-lg p-6">

                
                <h3 class="text-lg font-bold mb-4">
                    Bonjour <?php echo e(Auth::user()->pseudo); ?> !
                </h3>

                
                <ul class="mb-6">
                    <li><strong>Type de membre :</strong> <?php echo e(Auth::user()->type_membre); ?></li>
                    <li><strong>Points :</strong> <?php echo e(Auth::user()->points); ?></li>
                    <li><strong>Niveau :</strong> <?php echo e(Auth::user()->niveau); ?></li>
                </ul>

                
                <div class="flex flex-col gap-4 sm:flex-row">
                    <a href="<?php echo e(route('profil.index')); ?>" class="px-4 py-2 text-white bg-blue-600 rounded hover:bg-blue-700">
                        Voir mon profil
                    </a>
                    <a href="<?php echo e(route('objets.index')); ?>" class="px-4 py-2 text-white bg-green-600 rounded hover:bg-green-700">
                        Gérer mes objets connectés
                    </a>
                </div>

                
                <?php if(Auth::user()->type_membre === 'admin'): ?>
                <div class="mt-6 p-4 bg-gray-100 border rounded">
                    <p class="font-semibold">Fonctionnalités administrateur :</p>
                    <a href="<?php echo e(route('admin.panel')); ?>" class="text-blue-600 underline">
                        Accéder au panneau d'administration
                    </a>
                </div>
                <?php endif; ?>

            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?><?php /**PATH C:\Users\enora\OneDrive\Documents\ING 1\S2\maison_connectee\projet-maison\resources\views/dashboard.blade.php ENDPATH**/ ?>